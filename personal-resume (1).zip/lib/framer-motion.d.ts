declare module "framer-motion" {
  export const motion: any
}
